import pygame
import sys
import time
import random
import heapq

# Initialisation de Pygame
pygame.init()

# Dimensions de la fenêtre
LARGEUR = 1200
HAUTEUR = 600
TAILLE_CELLULE = 40

# Couleurs
BLANC = (255, 255, 255); NOIR = (0, 0, 0); VERT = (0, 255, 0)
ORANGE = (255, 165, 0); ROUGE = (255, 0, 0)
GRIS_FONCE = (80, 80, 80) # Couleur pour les feux éteints
JAUNE_PARKING = (255, 190, 0)

# Configuration de la fenêtre
fenetre = pygame.display.set_mode((LARGEUR, HAUTEUR))
pygame.display.set_caption("Simulation")
clock = pygame.time.Clock()

# --- Constantes ---
VITESSE_VOITURE = 2.0
DELAI_MIN_MOUVEMENT = 1.0 / VITESSE_VOITURE
SEUIL_BLOCAGE = 2.5
MAX_RECALCUL_ECHECS = 5


# --- AJOUT : Constantes et structures pour piétons ---
NB_PASSAGES_PIETONS = 5
COULEUR_PASSAGE = (220, 220, 220) # Gris clair pour les zebrures
COULEUR_PIETON = (0, 0, 0)       # Noir pour le piéton
VITESSE_PIETON = 0.02            # Fraction de la cellule traversée par frame (ajustez si besoin)
PROBA_APPARITION_PIETON = 0.005 # Probabilité qu'un piéton apparaisse sur un passage libre par frame

passages_pietons = [] # Liste des passages: [{'position': (x,y), 'orientation': 'h'/'v'}, ...]
pietons_actifs = []    # Liste des piétons: [{'id':id, 'passage_pos':(x,y), 'orientation': 'h'/'v', 'progres': 0.0-1.0}, ...]
prochain_id_pieton = 0


# --- CHARGEMENT IMAGE VOITURE BASE ---                       # NOUVEAU BLOC
car_image_base_scaled = None # Initialise à None
try:
    car_image_original = pygame.image.load('car.png').convert_alpha()
    car_width = int(TAILLE_CELLULE * 0.85) # Ajustez ce ratio si besoin
    car_height = int(car_image_original.get_height() * (car_width / car_image_original.get_width()))
    car_image_base_scaled = pygame.transform.scale(car_image_original, (car_width, car_height))
    print(f"Image de base 'car.png' chargée ({car_width}x{car_height}).")
except Exception as e:
    print(f"AVERTISSEMENT: Impossible de charger/redimensionner 'car.png'. Utilisation de cercles. Erreur: {e}")
# --- FIN CHARGEMENT IMAGE VOITURE BASE ---                   # FIN NOUVEAU BLOC

# --- Fonctions Utilitaires ---
# (creer_grille, ajouter_obstacle, forcer_recalcul_si_affecte - inchangées)
def creer_grille(taille_x, taille_y):
    return [[" " for _ in range(taille_x)] for _ in range(taille_y)]

def ajouter_obstacle(grille, x, y, feux):
    positions_feux = {feu["position"] for feu in feux}
    if (x, y) not in positions_feux and grille[y][x] != "X":
        grille[y][x] = "X"; return True
    return False

def forcer_recalcul_si_affecte(obstacle_x, obstacle_y, voitures):
    obstacle_pos = tuple([obstacle_x, obstacle_y])
    for v in voitures:
        chemin_tuples = [tuple(p) for p in v["chemin"]] if v["chemin"] else []
        if (obstacle_pos in chemin_tuples) or \
           (tuple(v["destination"]) == obstacle_pos and v["temps_arrivee"] is None):
            v["chemin"] = []; v["recalcul_echecs"] = 0



# --- Fonction : Initialisation Passages Piétons ---
def initialiser_passages_pietons(n_passages, taille_x, taille_y, feux, grille):
    """Place aléatoirement N passages piétons sur la grille."""
    nouveaux_passages = []
    positions_interdites = {f['position'] for f in feux} # Positions des feux
    # Ajouter les positions des obstacles initiaux s'il y en a déjà
    for y in range(taille_y):
        for x in range(taille_x):
            if grille[y][x] == 'X':
                positions_interdites.add((x,y))

    tentatives = 0
    while len(nouveaux_passages) < n_passages and tentatives < n_passages * 100:
        # Choisir une position aléatoire (éviter les bords pour simplifier)
        px = random.randrange(1, taille_x - 1)
        py = random.randrange(1, taille_y - 1)
        pos = (px, py)

        # Vérifier si la case est libre (pas un feu, pas un obstacle, pas déjà un passage)
        if pos not in positions_interdites and pos not in {p['position'] for p in nouveaux_passages}:
            # Choisir une orientation aléatoire
            orientation = random.choice(['horizontal', 'vertical'])
            passage = {'position': pos, 'orientation': orientation}
            nouveaux_passages.append(passage)
            positions_interdites.add(pos) # Marquer comme occupé pour ne pas en mettre deux au même endroit
        tentatives += 1

    if len(nouveaux_passages) < n_passages:
         print(f"Avertissement: N'a pu placer que {len(nouveaux_passages)} passages piétons sur {n_passages}.")

    print(f"Initialisé {len(nouveaux_passages)} passages piétons.")
    return nouveaux_passages


# --- NOUVELLES Fonctions : Gestion et Dessin Piétons/Passages ---
def mettre_a_jour_pietons(passages, pietons, voitures):
    """Gère l'apparition (évitant les voitures), le déplacement et la disparition des piétons."""
    global prochain_id_pieton

    # 1. Mise à jour des piétons existants (INCHANGÉ)
    pietons_restants = []
    for pieton in pietons:
        # --- AJOUT : Faire avancer le piéton seulement si le passage n'est PAS bloqué par une voiture ARRÊTÉE ---
        passage_pos = pieton['passage_pos']
        voiture_bloquante_sur_passage = any(
            tuple(v['position']) == passage_pos and v.get('bloquee_depuis') is not None
            for v in voitures if v['temps_arrivee'] is None
        )
        # Si le passage n'est pas bloqué par une voiture arrêtée DESSUS, le piéton avance
        if not voiture_bloquante_sur_passage:
             pieton['progres'] += VITESSE_PIETON
        # --- FIN AJOUT ---

        if pieton['progres'] < 1.0:
            pietons_restants.append(pieton) # Garder le piéton s'il n'a pas fini

    pietons[:] = pietons_restants

    # 2. Tentative d'apparition de nouveaux piétons
    # Le random.random() global réduit déjà la fréquence overall si PROBA_APPARITION_PIETON est bas
    if random.random() < PROBA_APPARITION_PIETON * len(passages):
        if not passages: return

        passage_choisi = random.choice(passages)
        pos_passage = passage_choisi['position']

        # Vérifier si un piéton utilise déjà ce passage
        passage_occupe_par_pieton = any(p['passage_pos'] == pos_passage for p in pietons)

        # --- AJOUT : Vérifier si une voiture occupe déjà la case du passage ---
        passage_occupe_par_voiture = any(
            tuple(v['position']) == pos_passage
            for v in voitures if v['temps_arrivee'] is None # Seulement voitures actives
        )
        # --- FIN AJOUT ---

        # N'apparaît que si le passage est libre de piétons ET de voitures
        if not passage_occupe_par_pieton and not passage_occupe_par_voiture:
            # Créer un nouveau piéton (INCHANGÉ)
            nouveau_pieton = {
                'id': prochain_id_pieton,
                'passage_pos': pos_passage,
                'orientation': passage_choisi['orientation'],
                'progres': 0.0
            }
            pietons.append(nouveau_pieton)
            prochain_id_pieton += 1


def dessiner_passages_pietons(fenetre, passages, taille_cellule, couleur=COULEUR_PASSAGE, largeur_zebre=5):
    """Dessine les zebrures des passages piétons."""
    marge = taille_cellule // 6 # Marge sur les côtés

    for passage in passages:
        x_cell, y_cell = passage['position']
        orientation = passage['orientation']
        cell_rect = pygame.Rect(x_cell * taille_cellule, y_cell * taille_cellule, taille_cellule, taille_cellule)

        if orientation == 'horizontal':
            # Rayures verticales
            y_debut = cell_rect.top + marge
            y_fin = cell_rect.bottom - marge
            x_courant = cell_rect.left + marge
            while x_courant < cell_rect.right - marge:
                 pygame.draw.line(fenetre, couleur, (x_courant, y_debut), (x_courant, y_fin), largeur_zebre)
                 x_courant += largeur_zebre * 2 # Avancer pour le prochain zebre (espace = largeur)
        else: # Vertical
             # Rayures horizontales
             x_debut = cell_rect.left + marge
             x_fin = cell_rect.right - marge
             y_courant = cell_rect.top + marge
             while y_courant < cell_rect.bottom - marge:
                 pygame.draw.line(fenetre, couleur, (x_debut, y_courant), (x_fin, y_courant), largeur_zebre)
                 y_courant += largeur_zebre * 2


# --- NOUVELLES Fonctions : Gestion et Dessin Piétons/Passages ---
def dessiner_pietons(fenetre, pietons, taille_cellule, couleur=COULEUR_PIETON, epaisseur_ligne=2):
    """Dessine les piétons actifs sous forme de bonhomme allumette."""
    demi_cell = taille_cellule // 2

    # --- Définir les dimensions relatives du bonhomme (ajustables) ---
    # Ces valeurs sont des fractions de la taille de la cellule pour l'échelle
    head_radius_ratio = 0.10  # Rayon de la tête
    torso_height_ratio = 0.25 # Hauteur du torse (corps)
    limb_length_ratio = 0.20  # Longueur des bras/jambes

    head_radius = max(2, int(taille_cellule * head_radius_ratio)) # Rayon tête en pixels
    torso_dy = max(3, int(taille_cellule * torso_height_ratio))    # Longueur verticale torse
    limb_len = max(3, int(taille_cellule * limb_length_ratio))    # Longueur bras/jambes

    for pieton in pietons:
        x_cell, y_cell = pieton['passage_pos']
        orientation = pieton['orientation']
        progres = pieton['progres']

        # Centre de la cellule du passage (inchangé)
        cx_cell = x_cell * taille_cellule + demi_cell
        cy_cell = y_cell * taille_cellule + demi_cell

        # Calcul de la position en pixels (inchangé - c'est le 'centre' global du piéton)
        px, py = cx_cell, cy_cell # Position centrale pour le calcul de la traversée
        if orientation == 'horizontal':
            start_x = cx_cell - demi_cell + head_radius * 2 # Ajuster pour ne pas sortir trop
            end_x = cx_cell + demi_cell - head_radius * 2
            px = start_x + (end_x - start_x) * progres
            py = cy_cell
        else: # Vertical
            start_y = cy_cell - demi_cell + head_radius * 2
            end_y = cy_cell + demi_cell - head_radius * 2
            py = start_y + (end_y - start_y) * progres
            px = cx_cell

        # Convertir en entiers pour le dessin
        center_x = int(px)
        center_y = int(py)

        # --- Calculer les points du bonhomme allumette RELATIFS au centre (px, py) ---
        # (0,0) relatif est maintenant au centre du corps

        # Tête
        head_center_y = center_y - (torso_dy // 2) - head_radius # Centre de la tête au-dessus du torse
        head_pos = (center_x, head_center_y)

        # Torse (corps vertical)
        torso_top_y = center_y - (torso_dy // 2)
        torso_bottom_y = center_y + (torso_dy // 2)
        torso_start = (center_x, torso_top_y)
        torso_end = (center_x, torso_bottom_y)

        # Point des "épaules" (approximativement en haut du torse)
        shoulder_y = torso_top_y + int(torso_dy * 0.1) # Un peu en dessous du cou
        shoulder_point = (center_x, shoulder_y)

        # Point des "hanches" (en bas du torse)
        hip_point = torso_end

        # Bras (en V vers le bas)
        arm_angle_offset_x = int(limb_len * 0.7) # Décalage horizontal
        arm_end_y = shoulder_y + int(limb_len * 0.7) # Fin des bras un peu plus bas
        left_arm_end = (center_x - arm_angle_offset_x, arm_end_y)
        right_arm_end = (center_x + arm_angle_offset_x, arm_end_y)

        # Jambes (en V inversé)
        leg_angle_offset_x = int(limb_len * 0.5) # Moins écartées que les bras
        leg_end_y = torso_bottom_y + limb_len
        left_leg_end = (center_x - leg_angle_offset_x, leg_end_y)
        right_leg_end = (center_x + leg_angle_offset_x, leg_end_y)


        # --- Dessiner le bonhomme ---
        # Tête
        pygame.draw.circle(fenetre, couleur, head_pos, head_radius)
        # Corps
        pygame.draw.line(fenetre, couleur, torso_start, torso_end, epaisseur_ligne)
        # Bras Gauche
        pygame.draw.line(fenetre, couleur, shoulder_point, left_arm_end, epaisseur_ligne)
        # Bras Droit
        pygame.draw.line(fenetre, couleur, shoulder_point, right_arm_end, epaisseur_ligne)
        # Jambe Gauche
        pygame.draw.line(fenetre, couleur, hip_point, left_leg_end, epaisseur_ligne)
        # Jambe Droite
        pygame.draw.line(fenetre, couleur, hip_point, right_leg_end, epaisseur_ligne)

# --- Fonctions Feux ---

def initialiser_feux_repartis(taille_y, taille_x):
    feux = []
    positions_occupees = set() # Ensemble pour éviter de superposer des feux
    
    # --- NOUVELLES CONTRAINTES ET COMPTEURS ---
    MAX_FEUX_PAR_LIGNE = 1  # Maximum 1 feu par ligne horizontale (gardé de votre code précédent)
    MAX_FEUX_PAR_COLONNE = 1 # Maximum 1 feu par colonne verticale (NOUVELLE contrainte)
    feux_par_ligne = {} # Dictionnaire {y_row: count}
    feux_par_colonne = {} # NOUVEAU Dictionnaire {x_col: count}
    # --- FIN NOUVEAUTES ---

    # Durées fixes
    d_v, d_o, d_r = 20, 3, 8 

    # Liste des intersections potentielles (cases où un feu PEUT être placé)
    intersections_potentielles = []
    for y in range(1, taille_y - 1):
        for x in range(1, taille_x - 1):
             intersections_potentielles.append((x, y))

    # Mélanger pour une distribution aléatoire
    random.shuffle(intersections_potentielles)

    # Parcourir les positions candidates
    for pos in intersections_potentielles:
        x, y = pos # Coordonnées de la position candidate

        # --- CONDITION DE PLACEMENT COMBINÉE ---
        # Vérifier :
        # 1. Que la limite de feux pour la LIGNE 'y' n'est pas atteinte
        # 2. Que la limite de feux pour la COLONNE 'x' n'est pas atteinte (NOUVEAU)
        # 3. Que la position 'pos' n'est pas déjà occupée par un feu placé précédemment
        if (feux_par_ligne.get(y, 0) < MAX_FEUX_PAR_LIGNE and
            feux_par_colonne.get(x, 0) < MAX_FEUX_PAR_COLONNE and
            pos not in positions_occupees):
            
            # Si toutes les conditions sont remplies, créer et ajouter le feu
            
            # Choix état initial et décalage (inchangé)
            if random.choice([True, False]):
                 etat = "vert"; d_act = d_v
            else:
                 etat = "rouge"; d_act = d_r
            decalage = random.uniform(0, d_act)

            # Création du dictionnaire feu (inchangé)
            feu = { "position": pos, "etat": etat, "duree_vert": d_v, 
                    "duree_orange": d_o, "duree_rouge": d_r, 
                    "duree_actuelle": d_act, 
                    "dernier_changement": time.time() - decalage }

            # Ajouter le feu à la liste
            feux.append(feu)
            # Marquer la position comme occupée
            positions_occupees.add(pos)
            
            # --- MISE A JOUR DES COMPTEURS ---
            # Incrémenter le compteur pour la ligne 'y'
            feux_par_ligne[y] = feux_par_ligne.get(y, 0) + 1
            # Incrémenter le compteur pour la colonne 'x' (NOUVEAU)
            feux_par_colonne[x] = feux_par_colonne.get(x, 0) + 1
            # --- FIN MISE A JOUR ---

    # Message final reflétant les deux contraintes
    print(f"Initialisé {len(feux)} feux (max {MAX_FEUX_PAR_LIGNE}/ligne, max {MAX_FEUX_PAR_COLONNE}/colonne) avec durées fixes (V:20s, O:3s, R:8s).")
    return feux

def mettre_a_jour_feux(feux):
    temps_actuel = time.time()
    for feu in feux:
        if temps_actuel - feu["dernier_changement"] > feu["duree_actuelle"]:
            if feu["etat"] == "vert":   feu["etat"] = "orange"; feu["duree_actuelle"] = feu["duree_orange"]
            elif feu["etat"] == "orange": feu["etat"] = "rouge";  feu["duree_actuelle"] = feu["duree_rouge"]
            elif feu["etat"] == "rouge":  feu["etat"] = "vert";   feu["duree_actuelle"] = feu["duree_vert"]
            feu["dernier_changement"] = temps_actuel


# --- Fonctions Directions ---
# (creer_directions_routes - inchangée)
def creer_directions_routes(taille_x, taille_y):
    directions_lignes = {y: "droite" if y % 2 == 0 else "gauche" for y in range(taille_y)}
    directions_colonnes = {x: "bas" if x % 2 == 0 else "haut" for x in range(taille_x)}
    return directions_lignes, directions_colonnes

# --- NOUVEAU : Fonction pour vérifier si une case a une sortie ---
def est_case_escapable(pos, taille_x, taille_y, directions_lignes, directions_colonnes, grille):
    """Vérifie s'il y a au moins une sortie valide depuis cette case."""
    x, y = pos
    # Vérifier sortie horizontale
    direction_ligne = directions_lignes.get(y)
    if direction_ligne == "droite" and x + 1 < taille_x and grille[y][x+1] != 'X':
        return True
    elif direction_ligne == "gauche" and x - 1 >= 0 and grille[y][x-1] != 'X':
        return True
    # Vérifier sortie verticale
    direction_colonne = directions_colonnes.get(x)
    if direction_colonne == "bas" and y + 1 < taille_y and grille[y+1][x] != 'X':
        return True
    elif direction_colonne == "haut" and y - 1 >= 0 and grille[y-1][x] != 'X':
        return True
    # Aucune sortie trouvée
    return False

# --- Fonctions Dessin ---
# (dessiner_grille, dessiner_obstacles, dessiner_feux, dessiner_directions, dessiner_voitures, dessiner_destinations - inchangées)
def dessiner_grille(fenetre, largeur, hauteur, taille_cellule):
    """Dessine la grille avec des lignes noires et une épaisseur personnalisée."""
    epaisseur_ligne = 2 # <- Définissez l'épaisseur souhaitée ici (ex: 2, 3, etc.)
    for x in range(0, largeur + 1, taille_cellule):
        pygame.draw.line(fenetre, NOIR, (x, 0), (x, hauteur), epaisseur_ligne) # Lignes verticales
    for y in range(0, hauteur + 1, taille_cellule):
        pygame.draw.line(fenetre, NOIR, (0, y), (largeur, y), epaisseur_ligne) # Lignes horizontales

def dessiner_obstacles(fenetre, grille, taille_cellule):
    for y in range(len(grille)):
        for x in range(len(grille[0])):
            if grille[y][x] == "X": pygame.draw.rect(fenetre, NOIR, (x*taille_cellule, y*taille_cellule, taille_cellule, taille_cellule))

def dessiner_feux(fenetre, feux, taille_cellule):
    """Dessine les feux comme trois petits cercles au centre de leur case."""
    for feu in feux:
        x, y = feu["position"]
        dc = taille_cellule // 2
        cx = x * taille_cellule + dc # Centre X de la case
        cy = y * taille_cellule + dc # Centre Y de la case

        # --- Paramètres visuels du feu ---
        # Ajustez ces valeurs si nécessaire
        rayon = max(3, taille_cellule // 8)  # Rayon de chaque petit cercle du feu (minimum 3 pixels)
        espacement_vertical = int(rayon * 2.2) # Espacement vertical entre les centres des cercles
        epaisseur_contour = 1 # Épaisseur du contour noir autour des cercles

        # --- Déterminer les couleurs actives/inactives ---
        etat_actuel = feu["etat"]
        couleur_inactive = GRIS_FONCE # Couleur quand le feu est éteint

        # Assigner la couleur vive si actif, sinon la couleur inactive
        couleur_r = ROUGE if etat_actuel == "rouge" else couleur_inactive
        couleur_o = ORANGE if etat_actuel == "orange" else couleur_inactive
        couleur_v = VERT if etat_actuel == "vert" else couleur_inactive

        # --- Calculer les positions des centres des cercles (verticalement) ---
        # Le feu orange est au centre de la case
        centre_r = (cx, cy - espacement_vertical) # Feu rouge en haut
        centre_o = (cx, cy)                      # Feu orange au milieu
        centre_v = (cx, cy + espacement_vertical) # Feu vert en bas

        # --- Dessiner les cercles (remplissage) ---
        pygame.draw.circle(fenetre, couleur_r, centre_r, rayon)
        pygame.draw.circle(fenetre, couleur_o, centre_o, rayon)
        pygame.draw.circle(fenetre, couleur_v, centre_v, rayon)

        # --- Dessiner les contours noirs (optionnel mais améliore la visibilité) ---
        if epaisseur_contour > 0:
            pygame.draw.circle(fenetre, NOIR, centre_r, rayon, epaisseur_contour)
            pygame.draw.circle(fenetre, NOIR, centre_o, rayon, epaisseur_contour)
            pygame.draw.circle(fenetre, NOIR, centre_v, rayon, epaisseur_contour)

def dessiner_directions(fenetre, directions_lignes, directions_colonnes, taille_x, taille_y, taille_cellule):
    tf = taille_cellule*0.3; dc = taille_cellule//2; cf = NOIR
    for y, direction in directions_lignes.items():
        cy = y*taille_cellule+dc
        if direction=="droite": cx=0*taille_cellule+dc; sp=(cx-tf/2, cy); ep=(cx+tf/2, cy); pygame.draw.line(fenetre,cf,sp,ep,2); pygame.draw.polygon(fenetre,cf,[(ep),(ep[0]-6,ep[1]-4),(ep[0]-6,ep[1]+4)])
        elif direction=="gauche": cx=(taille_x-1)*taille_cellule+dc; sp=(cx+tf/2, cy); ep=(cx-tf/2, cy); pygame.draw.line(fenetre,cf,sp,ep,2); pygame.draw.polygon(fenetre,cf,[(ep),(ep[0]+6,ep[1]-4),(ep[0]+6,ep[1]+4)])
    for x, direction in directions_colonnes.items():
        cx = x*taille_cellule+dc
        if direction=="bas": cy=0*taille_cellule+dc; sp=(cx, cy-tf/2); ep=(cx, cy+tf/2); pygame.draw.line(fenetre,cf,sp,ep,2); pygame.draw.polygon(fenetre,cf,[(ep),(ep[0]-4,ep[1]-6),(ep[0]+4,ep[1]-6)])
        elif direction=="haut": cy=(taille_y-1)*taille_cellule+dc; sp=(cx, cy+tf/2); ep=(cx, cy-tf/2); pygame.draw.line(fenetre,cf,sp,ep,2); pygame.draw.polygon(fenetre,cf,[(ep),(ep[0]-4,ep[1]+6),(ep[0]+4,ep[1]+6)])


# --- Fonctions Dessin ---
# ... (autres fonctions inchangées) ...

def dessiner_voitures(fenetre, voitures, taille_cellule):
    """Dessine les voitures, en appliquant une rotation spéciale de 90° si arrivée à destination."""
    t = time.time()
    font = pygame.font.Font(None, 16) # Police pour ID
    font_color_on_image = BLANC
    font_color_on_circle = BLANC
    dc = taille_cellule // 2
    ANGLE_PARKED = 90 # <<< Angle spécifique lorsque la voiture est garée (90° = face à gauche si image de base est vers le haut)

    for v in voitures:
        # Condition pour dessiner (active ou vient d'arriver) - reste la même
        if v["temps_arrivee"] is None or t - v["temps_arrivee"] < 1.0:
            x, y = v["position"]
            cx = x * taille_cellule + dc # Centre X cellule
            cy = y * taille_cellule + dc # Centre Y cellule

            voiture_img_base_colored = v.get("image") # Image de base déjà teintée

            if voiture_img_base_colored:
                # --- Déterminer l'angle de rotation ---
                final_angle = 0 # Angle par défaut
                is_arrived_event = v["temps_arrivee"] is not None
                is_at_destination_pos = tuple(v["position"]) == tuple(v["destination"])

                # Condition pour appliquer l'angle de parking:
                # La voiture doit être considérée comme arrivée ET être physiquement à sa destination
                if is_arrived_event and is_at_destination_pos:
                    final_angle = ANGLE_PARKED # Appliquer l'angle de "parking"
                else:
                    # Sinon, utiliser l'orientation normale de déplacement
                    final_angle = v.get("orientation", 0)

                # --- Appliquer la rotation ---
                # Pivoter l'image originale teintée avec l'angle déterminé
                rotated_img = pygame.transform.rotate(voiture_img_base_colored, final_angle)

                # Obtenir le nouveau rectangle et le RE-CENTRER
                rotated_rect = rotated_img.get_rect(center=(cx, cy))

                # Dessiner l'image tournée
                fenetre.blit(rotated_img, rotated_rect)

                # --- Dessiner l'ID (inchangé) ---
                txt_surface = font.render(str(v["id"]), True, font_color_on_image)
                text_rect = txt_surface.get_rect(center=rotated_rect.center)
                fenetre.blit(txt_surface, text_rect)

            else:
                # --- Fallback (Cercle - inchangé) ---
                r = dc - 5 # Rayon
                pygame.draw.circle(fenetre, v["couleur"], (cx, cy), r)
                # Dessiner l'ID sur le cercle
                txt_surface = font.render(str(v["id"]), True, font_color_on_circle)
                text_rect = txt_surface.get_rect(center=(cx, cy))
                fenetre.blit(txt_surface, text_rect)

# --- Fonctions Dessin ---

def dessiner_destinations(fenetre, voitures, taille_cellule, couleur_lignes=JAUNE_PARKING, epaisseur_lignes=2):
    """Dessine une seule place de parking stylisée pour chaque destination unique,
       avec l'ID de la première voiture associée."""
    t = time.time()
    font = pygame.font.Font(None, 16) # Police pour l'ID
    font_color_id = NOIR             # Couleur de l'ID sur la place

    # --- Paramètres visuels (inchangés) ---
    marge_laterale_ratio = 0.15
    marge_haut_ratio = 0.15
    marge_bas_ratio = 0.40
    longueur_pointille = max(4, taille_cellule // 10)
    espace_pointille = max(3, taille_cellule // 15)

    # --- ÉTAPE 1: Collecter les destinations uniques et un ID associé ---
    destinations_visibles = {} # Dictionnaire: { (dx, dy) : id_voiture }

    for v in voitures:
        # Considérer uniquement les voitures actives
        if v["temps_arrivee"] is None or t - v["temps_arrivee"] < 1.0:
            dest_tuple = tuple(v["destination"])
            # Si cette destination n'a pas encore été ajoutée, l'ajouter avec l'ID de cette voiture
            if dest_tuple not in destinations_visibles:
                destinations_visibles[dest_tuple] = v["id"]

    # --- ÉTAPE 2: Dessiner une seule place pour chaque destination unique ---
    for dest_pos, voiture_id in destinations_visibles.items():
        dx, dy = dest_pos # Récupérer les coordonnées de la destination

        # --- Calculs des coordonnées en pixels DANS la cellule ---
        cell_x = dx * taille_cellule
        cell_y = dy * taille_cellule
        marge_laterale_px = int(taille_cellule * marge_laterale_ratio)
        marge_haut_px = int(taille_cellule * marge_haut_ratio)
        marge_bas_px = int(taille_cellule * marge_bas_ratio) # Pour longueur lignes

        ligne_gauche_x = cell_x + marge_laterale_px
        ligne_droite_x = cell_x + taille_cellule - marge_laterale_px
        ligne_haut_y = cell_y + marge_haut_px
        ligne_bas_y = cell_y + taille_cellule - marge_bas_px # Fin des lignes latérales

        ligne_arriere_y = ligne_haut_y
        ligne_arriere_debut_x = ligne_gauche_x
        ligne_arriere_fin_x = ligne_droite_x

        # --- Dessin des lignes (comme avant) ---
        # Ligne latérale gauche
        pygame.draw.line(fenetre, couleur_lignes, (ligne_gauche_x, ligne_haut_y), (ligne_gauche_x, ligne_bas_y), epaisseur_lignes)
        # Ligne latérale droite
        pygame.draw.line(fenetre, couleur_lignes, (ligne_droite_x, ligne_haut_y), (ligne_droite_x, ligne_bas_y), epaisseur_lignes)
        # Ligne arrière (pointillée)
        x_courant = ligne_arriere_debut_x
        while x_courant < ligne_arriere_fin_x:
            x_fin_tiret = min(x_courant + longueur_pointille, ligne_arriere_fin_x)
            pygame.draw.line(fenetre, couleur_lignes, (x_courant, ligne_arriere_y), (x_fin_tiret, ligne_arriere_y), epaisseur_lignes)
            x_courant += longueur_pointille + espace_pointille

        # --- Dessin de l'ID de la voiture associée AU CENTRE DE LA PLACE ---
        centre_id_x = cell_x + taille_cellule // 2
        centre_id_y = (ligne_haut_y + ligne_bas_y) // 2 # Milieu vertical

        # Rendre le texte avec l'ID récupéré
        txt_surface = font.render(str(voiture_id), True, font_color_id)
        # Obtenir le rectangle et centrer
        text_rect = txt_surface.get_rect(center=(centre_id_x, centre_id_y))
        # Dessiner
        fenetre.blit(txt_surface, text_rect)


def generer_voitures_initiales(taille_x, taille_y, feux, grille, directions_lignes, directions_colonnes, img_base_voiture, n_voitures = 50): # Ajout de img_base_voiture
    voitures = []
    num_voiture = 1
    positions_feux = {feu["position"] for feu in feux}
    positions_occupees_initiales = set()
    tentatives_max_par_voiture = 100

    while len(voitures) < n_voitures and num_voiture < n_voitures * 3: # Limite un peu plus grande
        pos_initiale, dest = None, None
        # Trouver pos initiale ... (votre logique inchangée ici)
        for _ in range(tentatives_max_par_voiture):
            x_pos, y_pos = random.randrange(taille_x), random.randrange(taille_y)
            pos = (x_pos, y_pos)
            if pos not in positions_feux and \
               grille[y_pos][x_pos] != 'X' and \
               pos not in positions_occupees_initiales and \
               est_case_escapable(pos, taille_x, taille_y, directions_lignes, directions_colonnes, grille):
                pos_initiale = pos
                break
        if pos_initiale is None:
            break

        # Trouver destination ... (votre logique inchangée ici)
        for _ in range(tentatives_max_par_voiture):
            x_dest, y_dest = random.randrange(taille_x), random.randrange(taille_y)
            d = (x_dest, y_dest)
            if d != pos_initiale and \
               d not in positions_feux and \
               grille[y_dest][x_dest] != 'X' and \
               est_case_escapable(d, taille_x, taille_y, directions_lignes, directions_colonnes, grille):
                 dest = d
                 break
        if dest is None:
            continue

        # Marquer la position comme occupée
        positions_occupees_initiales.add(pos_initiale)

        # Création couleur et image spécifique (votre logique déjà présente)
        voiture_couleur = (random.randint(0,150), random.randint(0,150), random.randint(100,255))
        voiture_image_specifique = None
        if img_base_voiture:
            try:
                voiture_image_specifique = img_base_voiture.copy()
                voiture_image_specifique.fill(voiture_couleur, special_flags=pygame.BLEND_RGB_MULT)
            except Exception as img_err:
                print(f"Erreur coloration voiture {num_voiture}: {img_err}")
                voiture_image_specifique = None

        # Création du dictionnaire voiture
        voiture = {
            "id": num_voiture,
            "position": list(pos_initiale),
            "destination": list(dest),
            "chemin": [],
            "temps_arrivee": None,
            "dernier_deplacement": time.time(),
            "couleur": voiture_couleur,
            "image": voiture_image_specifique,
            "orientation": 0,                      # <<< AJOUT: Orientation initiale (0 = HAUT par défaut)
            "bloquee_depuis": None,
            "recalcul_echecs": 0
        }

        voitures.append(voiture);
        num_voiture += 1

    print(f"Généré {len(voitures)} voitures.")
    return voitures

# --- MODIFIÉ : Utilisation de est_case_escapable ---
def trouver_nouvelle_destination_valide(voiture_actuelle, taille_x, taille_y, feux, grille, directions_lignes, directions_colonnes, voitures):
    """Trouve une nouvelle destination aléatoire valide ET escapable."""
    positions_feux = {feu["position"] for feu in feux}

    for _ in range(100):
        x_dest = random.randrange(taille_x)
        y_dest = random.randrange(taille_y)
        dest = (x_dest, y_dest)
        pos_actuelle = tuple(voiture_actuelle["position"])

        if dest != pos_actuelle and \
           dest not in positions_feux and \
           grille[y_dest][x_dest] != 'X' and \
           est_case_escapable(dest, taille_x, taille_y, directions_lignes, directions_colonnes, grille): # Vérif escapade
            return list(dest)
    return None # Echec

# (trouver_chemin - inchangée)
def trouver_chemin(grille, depart, arrivee, directions_lignes, directions_colonnes):
    def heuristique(a, b): return abs(a[0] - b[0]) + abs(a[1] - b[1])
    depart, arrivee = tuple(depart), tuple(arrivee); tx, ty = len(grille[0]), len(grille)
    if not (0<=depart[0]<tx and 0<=depart[1]<ty and 0<=arrivee[0]<tx and 0<=arrivee[1]<ty): return None
    if grille[depart[1]][depart[0]]=="X" or grille[arrivee[1]][arrivee[0]]=="X": return None
    if depart == arrivee: return [list(depart)]
    ouverte = [(heuristique(depart, arrivee), depart)]; precedent, cout_g = {depart: None}, {depart: 0}
    while ouverte:
        _, courant = heapq.heappop(ouverte)
        if courant == arrivee:
            chemin = []; temp = courant
            while temp: chemin.append(list(temp)); temp = precedent.get(temp)
            return chemin[::-1]
        x, y = courant; voisins = []
        dir_l, dir_c = directions_lignes.get(y), directions_colonnes.get(x)
        if dir_l == "droite" and x+1 < tx: voisins.append((x+1, y))
        elif dir_l == "gauche" and x-1 >= 0: voisins.append((x-1, y))
        if dir_c == "bas" and y+1 < ty: voisins.append((x, y+1))
        elif dir_c == "haut" and y-1 >= 0: voisins.append((x, y-1))
        for voisin in voisins:
            vx, vy = voisin
            if grille[vy][vx] == "X": continue
            n_cout_g = cout_g[courant] + 1
            if voisin not in cout_g or n_cout_g < cout_g[voisin]:
                cout_g[voisin] = n_cout_g; priorite = n_cout_g + heuristique(voisin, arrivee)
                heapq.heappush(ouverte, (priorite, voisin)); precedent[voisin] = courant
    return None



def mettre_a_jour_voitures(voitures, grille, feux, directions_lignes, directions_colonnes, taille_x, taille_y, pietons): # Ajout de pietons  
    temps_actuel = time.time()
    intentions = {} # Stocke la paire (next_pos, ready) pour chaque voiture

    # 1. Calcul chemins et intentions 
    for v in voitures:
        if v["temps_arrivee"]: continue
        pos_tuple = tuple(v["position"])
        if pos_tuple == tuple(v["destination"]):
            v["temps_arrivee"] = temps_actuel; v["chemin"] = []; v["bloquee_depuis"] = None; v["recalcul_echecs"] = 0
            continue

        recalcul_demande = not v["chemin"] or \
                           (v["bloquee_depuis"] and temps_actuel - v["bloquee_depuis"] > SEUIL_BLOCAGE)

        if recalcul_demande:
            # ... (votre logique de recalcul inchangée) ...
             path = trouver_chemin(grille, v["position"], v["destination"], directions_lignes, directions_colonnes)
             if path and len(path) > 1:
                 v["chemin"] = path[1:]; v["bloquee_depuis"] = None; v["recalcul_echecs"] = 0
             else:
                 if v["bloquee_depuis"]: v["recalcul_echecs"] += 1
                 else: v["recalcul_echecs"] = 1
                 v["chemin"] = []; v["bloquee_depuis"] = v["bloquee_depuis"] or temps_actuel

                 if v["recalcul_echecs"] > MAX_RECALCUL_ECHECS:
                     nouvelle_dest = trouver_nouvelle_destination_valide(
                         v, taille_x, taille_y, feux, grille, directions_lignes, directions_colonnes, voitures
                     )
                     if nouvelle_dest:
                         v["destination"] = nouvelle_dest
                         path_nouv = trouver_chemin(grille, v["position"], v["destination"], directions_lignes, directions_colonnes)
                         v["chemin"] = path_nouv[1:] if path_nouv and len(path_nouv)>1 else []
                         v["bloquee_depuis"] = None if v["chemin"] else temps_actuel
                         v["recalcul_echecs"] = 0
                     else:
                         v["recalcul_echecs"] = 0 # Éviter boucle

        # Déterminer l'intention (inchangé)
        next_pos = tuple(v["chemin"][0]) if v["chemin"] else pos_tuple
        ready = bool(v["chemin"]) and (temps_actuel - v["dernier_deplacement"] >= DELAI_MIN_MOUVEMENT) # S'assurer que ready est booléen
        intentions[v["id"]] = (next_pos, ready)

    # 2. Résolution conflits et Mouvements
    final_pos_tick = set() # Cases qui seront occupées à la fin de ce tick
    voitures_shuffled = [v for v in voitures if not v["temps_arrivee"]]
    random.shuffle(voitures_shuffled) # Ordre aléatoire

    # Initialiser final_pos_tick avec les positions actuelles des voitures qui pourraient ne pas bouger
    for v in voitures_shuffled:
         final_pos_tick.add(tuple(v["position"])) # On suppose qu'elles ne bougent pas au départ

    for v in voitures_shuffled:
        id_v = v["id"]
        current_pos = tuple(v["position"])
        next_pos_wanted, is_ready = intentions.get(id_v, (current_pos, False)) # Récupère intention
        can_move = is_ready and next_pos_wanted != current_pos # Condition de base pour vouloir bouger

        # Si la voiture veut bouger, vérifier les obstacles
        if can_move:
            vx, vy = next_pos_wanted
            if grille[vy][vx] == 'X':
                can_move = False; v["chemin"] = []; v["recalcul_echecs"]=0
                # Si bloqué par X, marquer comme bloqué si pas déjà
                if not v["bloquee_depuis"]: v["bloquee_depuis"] = temps_actuel
            if can_move:
                for feu in feux:
                    if feu["position"] == next_pos_wanted and feu["etat"] != "vert":
                         can_move = False
                         # Si bloqué par Feu, marquer comme bloqué si pas déjà
                         if not v["bloquee_depuis"]: v["bloquee_depuis"] = temps_actuel
                         break
            if can_move:
                 # Vérifier si la case cible est occupée par une AUTRE voiture A LA FIN DE CE TICK
                 # (on a initialisé final_pos_tick avec les pos actuelles)
                 # S'il y a collision potentielle (2 voitures veulent la même case, ou une veut aller où l'autre reste)
                 if next_pos_wanted in final_pos_tick and next_pos_wanted != current_pos : # Vérifier si la cible est occupée par une *autre* voiture
                    can_move = False
                    # Si bloqué par trafic, marquer comme bloqué si pas déjà
                    if not v["bloquee_depuis"]: v["bloquee_depuis"] = temps_actuel
            
            # --- AJOUT: Vérif Piétons sur la case cible ---
            if can_move:
                for pieton in pietons:
                    # Si un piéton est sur la case où la voiture veut aller
                    if pieton['passage_pos'] == next_pos_wanted:
                        can_move = False
                        # print(f"Voiture {v['id']} bloquée par piéton {pieton['id']} à {next_pos_wanted}")
                        if not v["bloquee_depuis"]: v["bloquee_depuis"] = temps_actuel # Bloqué par piéton
                        break # Un seul piéton suffit à bloquer
            # --- FIN AJOUT ---

        # Si le mouvement est effectivement possible ET souhaité
        if can_move:
            final_decision = next_pos_wanted # La décision finale est de bouger

            # --- AJOUT: Calculer la nouvelle orientation ---
            dx = final_decision[0] - current_pos[0] # Différence X
            dy = final_decision[1] - current_pos[1] # Différence Y
            new_angle = v.get('orientation', 0) # Garde l'ancien angle par défaut
            if dy < 0:    # Monte
                new_angle = 90    # 90 degrés
            elif dy > 0:  # Descend
                new_angle = 270  # -90 degrés (ou 270)
            elif dx > 0:  # Va à droite
                new_angle = 0  # 0 degrés
            elif dx < 0:  # Va à gauche
                new_angle = 180   # 180 degrés
            v['orientation'] = new_angle # Mettre à jour l'orientation de la voiture
            # --- FIN AJOUT ---

            # Mettre à jour la position et l'état de la voiture
            v["position"] = list(final_decision)
            if v["chemin"]: v["chemin"].pop(0) # Retirer l'étape effectuée
            v["dernier_deplacement"] = temps_actuel
            v["bloquee_depuis"] = None # N'est plus bloquée
            v["recalcul_echecs"] = 0

            # Mettre à jour les positions occupées : libérer l'ancienne, occuper la nouvelle
            if current_pos in final_pos_tick: # Devrait toujours être vrai sauf si 2 voitures étaient superposées
                final_pos_tick.remove(current_pos)
            final_pos_tick.add(final_decision)

        # Si la voiture ne peut pas ou ne veut pas bouger (elle reste sur current_pos)
        # Et si elle n'est pas à destination, s'assurer qu'elle est marquée bloquée si ce n'est pas déjà le cas
        elif current_pos != tuple(v["destination"]) and not v["bloquee_depuis"] and v['temps_arrivee'] is None:
             v["bloquee_depuis"] = temps_actuel


# --- Initialisation & Boucle Principale ---
taille_x = LARGEUR // TAILLE_CELLULE
taille_y = HAUTEUR // TAILLE_CELLULE
grille = creer_grille(taille_x, taille_y)
feux = initialiser_feux_repartis(taille_y, taille_x)

# --- AJOUT INITIALISATION PASSAGES ---
passages_pietons = initialiser_passages_pietons(NB_PASSAGES_PIETONS, taille_x, taille_y, feux, grille)
pietons_actifs = [] # Initialiser la liste des piétons
prochain_id_pieton = 0
# --- FIN AJOUT ---

lignes_directions, colonnes_directions = creer_directions_routes(taille_x, taille_y)
nombre_initial_voitures = 100
# --- MODIFIÉ : Passer les directions à la génération ---
voitures = generer_voitures_initiales(
    taille_x, taille_y, feux, grille, lignes_directions, colonnes_directions,
    car_image_base_scaled,  # <<< AJOUTER CET ARGUMENT
    n_voitures=nombre_initial_voitures
)

running = True
while running:
    dt = clock.tick(30) / 1000.0

    for event in pygame.event.get():
        if event.type == pygame.QUIT: running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            cx, cy = event.pos[0] // TAILLE_CELLULE, event.pos[1] // TAILLE_CELLULE
            if 0 <= cx < taille_x and 0 <= cy < taille_y:
                 if event.button == 1: # Clic Gauche: Obstacle
                     if ajouter_obstacle(grille, cx, cy, feux):
                          forcer_recalcul_si_affecte(cx, cy, voitures)
                 elif event.button == 3: # Clic Droit: Retirer Obstacle
                     if grille[cy][cx] == 'X': grille[cy][cx] = ' '

    mettre_a_jour_feux(feux)

    # --- AJOUT MISE A JOUR PIETONS ---
    mettre_a_jour_pietons(passages_pietons, pietons_actifs, voitures)    # --- FIN AJOUT ---
    # --- MODIFICATION APPEL VOITURES ---
    mettre_a_jour_voitures(voitures, grille, feux, lignes_directions, colonnes_directions, taille_x, taille_y, pietons_actifs) # Passer pietons_actifs
    # --- FIN MODIFICATION ---
   
    fenetre.fill(BLANC)
    dessiner_grille(fenetre, LARGEUR, HAUTEUR, TAILLE_CELLULE)
    dessiner_obstacles(fenetre, grille, TAILLE_CELLULE)
    # --- AJOUT DESSIN PASSAGES ---
    dessiner_passages_pietons(fenetre, passages_pietons, TAILLE_CELLULE)
    # --- FIN AJOUT ---
    dessiner_directions(fenetre, lignes_directions, colonnes_directions, taille_x, taille_y, TAILLE_CELLULE)
    dessiner_feux(fenetre, feux, TAILLE_CELLULE)
    dessiner_destinations(fenetre, voitures, TAILLE_CELLULE)
     # --- AJOUT DESSIN PIETONS ---
    dessiner_pietons(fenetre, pietons_actifs, TAILLE_CELLULE)
    # --- FIN AJOUT ---
    dessiner_voitures(fenetre, voitures, TAILLE_CELLULE) # Dessiner voitures après piétons

    pygame.display.flip()

pygame.quit()
sys.exit()